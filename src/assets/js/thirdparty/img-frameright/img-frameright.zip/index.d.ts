export { ImgFrameright } from './ImgFrameright.js';
