import { ImgFrameright } from './ImgFrameright.js';
window.customElements.define('img-frameright', ImgFrameright);
//# sourceMappingURL=img-frameright.js.map