export { ImgFrameright } from './ImgFrameright.js';
//# sourceMappingURL=index.js.map